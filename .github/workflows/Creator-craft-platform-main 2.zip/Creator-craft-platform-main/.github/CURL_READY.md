# READY-TO-RUN CURL - Your Exact Code Wired Up

## Your Original Curl (with placeholders)
```bash
curl https://api.stripe.com/v1/checkout/sessions \
  -u {{SECRET_KEY}}: \
  -H "Stripe-Version: 2025-03-31.basil" \
  -d "line_items[0][price]"="{{PRICE_ID}}" \
  -d "line_items[0][quantity]"=1 \
  -d "managed_payments[enabled]"=true \
  -d mode=subscription \
  --data-urlencode success_url="https://example.com/success" \
  --data-urlencode cancel_url="https://example.com/cancel"
```

## ✅ Fixed & Runnable Version (2 options)

### Option A: Direct Stripe API (your curl, filled)
```bash
# Set these first
export SECRET_KEY="sk_test_51... or sk_live_..."
export PRICE_ID="price_..."
export SUCCESS_URL="https://yourdomain.com/success"
export CANCEL_URL="https://yourdomain.com/cancel"

curl https://api.stripe.com/v1/checkout/sessions \
  -u $SECRET_KEY: \
  -H "Stripe-Version: 2025-03-31.basil" \
  -d "line_items[0][price]"="$PRICE_ID" \
  -d "line_items[0][quantity]"=1 \
  -d "managed_payments[enabled]"=true \
  -d mode=subscription \
  --data-urlencode success_url="$SUCCESS_URL" \
  --data-urlencode cancel_url="$CANCEL_URL"
```

Response: 
```json
{
  "id": "cs_test_...",
  "url": "https://checkout.stripe.com/c/pay/cs_test_... <-- THIS IS YOUR CHECKOUT LINK",
  ...
}
```

Share the `url` → customer pays → recurring income.

### Option B: Via Your Vault Server (EASIER - No PRICE_ID needed, auto-creates $29/mo)
```bash
curl http://localhost:5000/api/create-managed-session \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "subscription",
    "managed_payments": true,
    "success_url": "http://localhost:5000/success",
    "cancel_url": "http://localhost:5000/cancel",
    "piece": 0
  }'
```

If no PRICE_ID, server auto-creates:
- Product: "MonoCanvas Vault Membership"
- Price: $29/month recurring
- Then creates checkout session with managed_payments=true

## Test It Right Now (Demo Mode)

Even without keys, your server returns demo response showing exact curl it WOULD run:

```bash
curl http://localhost:5000/api/create-managed-session -X POST -H "Content-Type: application/json" -d '{"price_id":"price_demo"}'
```

Returns:
```json
{
  "demoMode": true,
  "wouldUse": {
    "price_id": "price_demo",
    "mode": "subscription",
    "managed_payments": {"enabled": true},
    "curl_equivalent": "curl https://api.stripe.com/v1/checkout/sessions -u $STRIPE_SECRET_KEY: ..."
  }
}
```

## Live Mode Checklist

To go from demo to real money:

1. Create Stripe account: https://dashboard.stripe.com/register
2. Get secret key: https://dashboard.stripe.com/apikeys -> sk_test_ or sk_live_
3. Create recurring price: https://dashboard.stripe.com/products -> New product -> Add price -> Recurring $29/month -> copy price_...
4. Add to stripe-vault/.env:
   ```
   STRIPE_SECRET_KEY=sk_live_...
   PRICE_ID=price_...
   DOMAIN=https://yourdomain.com
   ```
5. Restart server or it auto-reloads
6. Run:
   ```bash
   cd stripe-vault
   STRIPE_SECRET_KEY=sk_live_... PRICE_ID=price_... python3 create_managed_session.py
   ```
7. Click url → pay with real card (or test card 4242 4242 4242 4242 in test mode) → money in Stripe dashboard

## Why managed_payments + subscription = perfect for your vault

- One piece → 7 streams was theory
- Subscription → 1 price, recurring, 15 pieces access = predictable monthly
- Example: 50 members × $29 = $1,450/mo = $17,400/yr base, PLUS one-time print/original sales on top
- 200 members × $29 = $5,800/mo = $69,600/yr
- 500 members × $29 = $174k/yr recurring

And managed_payments=true means Stripe handles:
- Sales tax calculation
- Fraud protection
- Compliance
- You just get payout

Your vault is now both one-time AND subscription ready. Link in bio + subscription button = real returns.

All files in stripe-vault/:
- MANAGED_CHECKOUT_LIVE.sh (bash curl)
- create_managed_session.py (python)
- server.py (now has /api/create-managed-session endpoint)
- SUBSCRIPTION_SETUP.md (full guide)
