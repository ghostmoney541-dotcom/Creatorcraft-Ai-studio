# MonoCanvas STRIPE VAULT - Real Money System 💸

Your 15 pieces → 105 Stripe products → Real returns. LIVE server is in this folder.

## YOU ALREADY HAVE THE HARD PART
- 15 original images in `/uploads`
- Vault frontend with 105 income streams
- Revenue lab that proved ~$1.29M/yr optimistic model

## NOW WE GO LIVE (15 MINUTES)

### 1. Get Stripe Keys (2 min)
1. Go to https://dashboard.stripe.com/register (or login)
2. Get keys: https://dashboard.stripe.com/apikeys
   - `Publishable key` = pk_test... or pk_live...
   - `Secret key` = sk_test... or sk_live...
3. Copy `.env.example` → `.env` in this folder
4. Paste keys

```bash
cd stripe-vault
cp .env.example .env
# edit .env with your keys
nano .env
```

### 2. Start Live Server (30 sec)
```bash
pip install -r requirements.txt
python3 server.py
# Open http://localhost:5000
```

You now have a LIVE checkout vault! Demo mode switches to LIVE automatically when keys are detected.

### 3. (Optional) Bulk Create 105 Products in Stripe
```bash
python3 setup_stripe_products.py
```
This creates all 105 products + payment links in your Stripe dashboard. You get `stripe_products.json` with all links.

### 4. Connect Print Fulfillment = Passive Money
This is how prints/merch become passive:

**Printful (recommended) or Printify:**
1. Create account at printful.com
2. Connect to Stripe (or use manual orders at first)
3. Upload your 15 images once
4. Create products: canvas prints, tees, hoodies
5. When order comes from Stripe vault:
   - You get email with money
   - Forward order to Printful (or auto via Zapier/Make)
   - Printful prints + ships → customer
   - You keep $40-120 profit per print, no inventory

**Zapier automation (once you have volume):**
Stripe Checkout success → Create Printful order → Done. Fully passive.

### 5. Course = $49 instant delivery
Record one 30-60 min video "How I painted Piece 01" → upload to Gumroad or just Google Drive link.

In `server.py`, after successful checkout you can auto-email the drive link. For now:
- Check `/api/sales` or Stripe dashboard → manually email link
- Upgrade later to auto-email via SendGrid

### 6. Licensing & Collabs = Big tickets
The two forms on the page save to `leads.csv` and `leads.json`.

Close script: "$2k/yr for lobby use, $18k for full brand library"

## FILE MAP
- `server.py` - Flask + Stripe engine (main)
- `templates/index.html` - Vault frontend with live buy buttons
- `.env.example` - What keys you need
- `setup_stripe_products.py` - Bulk create Stripe products
- `requirements.txt` - Python deps
- `leads.csv` - Where license/collab leads go (real money leads)
- `sales.json` - Stripe webhook sale log (when webhook configured)

## PRICING TO EDIT
Open `server.py` → `PRICING` dict:
```python
PRICING = {
  "original": 4500_00,  # $4500
  "print_small": 65_00,
  ...
}
```
Change to your real prices. Sliders in your old vault still useful for testing.

## GOING TO PRODUCTION
- **Domain:** Set `DOMAIN=https://yourdomain.com` in .env
- **Deploy:** Easiest = https://render.com or https://railway.app
  - Push this folder to GitHub → connect → set env vars → deploy
- **Webhook (for auto-fulfill):** In Stripe dashboard → Developers → Webhooks → Add endpoint `https://yourdomain.com/webhook` → copy secret to `.env` as `STRIPE_WEBHOOK_SECRET`

## YOUR FIRST $1000 PLAN
Today:
- [ ] Add Stripe keys → live mode
- [ ] Buy your own Piece 01 original for $1 test → verify money hits Stripe
- [ ] Share vault link to 3 collectors / Instagram story

Week 1:
- [ ] Upload 15 designs to Printful → connect 3 products (print small, tee, hoodie)
- [ ] Set up 1 course video (even phone recording + timelapse = $49 value)
- [ ] Post "Vault is live" → link in bio → Stripe checkout is now your gallery

This is REAL money, not mock numbers. Every button → Stripe → your bank account (2 day payout).

Let's goooo 🔥
